(0-1)*0.0 < 0.0
(0-1)*0.0 <= 0.0
4 < 5
9 >= 10
9 <= 10
"hi" < 8
"hi" < "hithere"
true > false
10 > 8
5 == 5
5 == 8.0
8 == 8.0
true == 1
false == true
(0-1)*0.0 == 0.0
"hello" == "hello"
"hi" != "hi"
null != false

3 < 4 && 5 < 10
3 < 4 && 5 == 10
3 < 4 || 5 == 10
7 >= 10 || 3 > 2
5 / 0 == 0 || 5 == 5
5 == 5 || 5 / 0 == 0
false || true && true
false || false && true
true || false && true
3 || true
